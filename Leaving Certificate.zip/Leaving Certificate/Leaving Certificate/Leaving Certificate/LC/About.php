<!DOCTYPE html>
<html lang="en">

<head>
    
    <title>Home Page - Leaving Certificate </title>


    <!-- Core Stylesheet 
    <link href="style.css" rel="stylesheet">-->

    <!-- Responsive CSS -->
  <!--  <link href="css/responsive/responsive.css" rel="stylesheet">-->

</head>

<body class="2">

    
<center>  <img src="img/bg-img/hod.png"><h2>HOD</h2> </center>
  <center> <img src="img/bg-img/21.png"><h2>Teacher</h2></center>
  <center><h2> Developer Team</h2></center>
  <center> <img src="img/bg-img/17.png"><h2>Ranaware Nikhil Sunil          1810510261</h2></center>
  <center> <img src="img/bg-img/20.png"><h2>Konale Diksha Dilip            1810510247</h2></center>
  <center> <img src="img/bg-img/19.png"><h2> Katkar Sumit Suryakant         1810510232</h2></center>
  <center> <img src="img/bg-img/18.png"><h2>Tambade shubham Shivaji        1810510240</h2></center>
   
   
   <div class="fancy-hero-area bg-img bg-overlay animated-img" style="background-image: url(img/bg-img/hr.jpg);">

        <h2>  <center> Project Team</center></h2>
        <h2>  <center> Ranaware Nikhil Sunil          1810510261 </center></h2>
        <h2>  <center> Konale Diksha Dilip            1810510247 </center></h2>
        <h2>  <center> Katkar Sumit Suryakant         1810510232 </center></h2>
        <h2>  <center> Tambade shubham Shivaji        1810510240 </center></h2>


      <center> <h2>Infromation</h2></center>  
      <h2>add information</h2>
    </div>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap-4 js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/others/plugins.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>
</body>